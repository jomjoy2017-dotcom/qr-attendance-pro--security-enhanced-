    </main>
    <footer class="text-center py-10 text-gray-400 text-sm">
        &copy; <?php echo date('Y'); ?> QR Attendance Pro. System Secured with PDO & CSRF Protection.
    </footer>
</body>
</html>