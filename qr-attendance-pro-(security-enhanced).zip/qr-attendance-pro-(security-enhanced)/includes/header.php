<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR Attendance Pro</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt:wght@300;400;600&display=swap" rel="stylesheet">
    <style>body { font-family: 'Prompt', sans-serif; }</style>
</head>
<body class="bg-gray-100 min-h-screen">
    <nav class="bg-indigo-700 text-white shadow-xl">
        <div class="max-w-7xl mx-auto px-4">
            <div class="flex justify-between h-16">
                <div class="flex items-center space-x-8">
                    <a href="index.php" class="text-xl font-bold flex items-center">
                        <span class="mr-2">⏱️</span> QR Attendance
                    </a>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <div class="hidden md:flex space-x-4">
                            <a href="index.php" class="hover:bg-indigo-800 px-3 py-2 rounded transition">แดชบอร์ด</a>
                            <a href="history.php" class="hover:bg-indigo-800 px-3 py-2 rounded transition">ประวัติเข้างาน</a>
                            <?php if($_SESSION['role'] !== 'employee'): ?>
                                <a href="scan.php" class="hover:bg-indigo-800 px-3 py-2 rounded transition">เครื่องสแกน</a>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                </div>
                <div class="flex items-center space-x-4">
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <span class="text-sm">สวัสดี, <?php echo htmlspecialchars($_SESSION['name']); ?></span>
                        <a href="logout.php" class="bg-rose-500 hover:bg-rose-600 px-4 py-2 rounded text-sm font-medium">ออก</a>
                    <?php else: ?>
                        <a href="login.php" class="text-sm">เข้าสู่ระบบ</a>
                        <a href="register.php" class="bg-white text-indigo-700 px-4 py-2 rounded text-sm font-bold">สมัครใหม่</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </nav>
    <main class="max-w-7xl mx-auto px-4 py-8">