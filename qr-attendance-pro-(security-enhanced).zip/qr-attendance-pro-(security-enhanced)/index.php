<?php
require_once 'config.php';
checkLogin();
include 'includes/header.php';

$stmt = $pdo->prepare("SELECT 
    (SELECT COUNT(*) FROM attendance WHERE work_date = CURDATE()) as today_in,
    (SELECT COUNT(*) FROM attendance WHERE work_date = CURDATE() AND status = 'late') as late_count
");
$stmt->execute();
$stats = $stmt->fetch();
?>

<div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
    <div class="bg-white p-6 rounded-2xl shadow-sm border-b-4 border-indigo-500">
        <p class="text-gray-400 text-sm uppercase font-bold">มาทำงานวันนี้</p>
        <p class="text-4xl font-black text-indigo-900"><?php echo (int)$stats['today_in']; ?> <span class="text-lg font-normal">คน</span></p>
    </div>
    <div class="bg-white p-6 rounded-2xl shadow-sm border-b-4 border-rose-500">
        <p class="text-gray-400 text-sm uppercase font-bold">มาสาย</p>
        <p class="text-4xl font-black text-rose-600"><?php echo (int)$stats['late_count']; ?> <span class="text-lg font-normal">คน</span></p>
    </div>
    <div class="bg-white p-6 rounded-2xl shadow-sm border-b-4 border-emerald-500">
        <p class="text-gray-400 text-sm uppercase font-bold">เวลาปัจจุบัน</p>
        <p id="timer" class="text-4xl font-black text-emerald-700 font-mono">00:00:00</p>
    </div>
</div>

<div class="bg-white rounded-3xl shadow-lg overflow-hidden flex flex-col md:flex-row">
    <div class="md:w-1/3 bg-indigo-50 p-10 flex flex-col items-center justify-center border-r">
        <h3 class="text-xl font-bold text-indigo-900 mb-6">QR Code ของคุณ</h3>
        <div class="bg-white p-4 rounded-2xl shadow-inner border-2 border-indigo-200">
            <img src="https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=<?php echo urlencode($_SESSION['employee_code']); ?>" alt="QR">
        </div>
        <p class="mt-6 font-mono font-bold text-indigo-700 bg-indigo-200 px-4 py-1 rounded-full">
            <?php echo htmlspecialchars($_SESSION['employee_code']); ?>
        </p>
    </div>
    <div class="md:w-2/3 p-10">
        <h3 class="text-2xl font-bold mb-4">ยินดีต้อนรับ, <?php echo htmlspecialchars($_SESSION['name']); ?></h3>
        <p class="text-gray-600 mb-6">ระบบลงเวลาพนักงานด้วยรหัส QR Code กรุณาแสดงรหัสทางซ้ายมือที่เครื่องสแกนเพื่อทำการบันทึกเวลาเข้าและออกงาน</p>
        <div class="space-y-4">
            <div class="flex items-center p-4 bg-gray-50 rounded-xl">
                <span class="text-2xl mr-4">🏢</span>
                <div>
                    <p class="text-sm font-bold">นโยบายบริษัท</p>
                    <p class="text-xs text-gray-500">เข้างานก่อน 09:00 น. เพื่อรักษาสถานะปกติ</p>
                </div>
            </div>
            <a href="history.php" class="inline-block bg-indigo-600 text-white px-6 py-3 rounded-xl font-bold hover:bg-indigo-700 transition">ดูประวัติของฉัน</a>
        </div>
    </div>
</div>

<script>
    function tick() {
        const now = new Date();
        document.getElementById('timer').textContent = now.toLocaleTimeString('th-TH', { hour12: false });
    }
    setInterval(tick, 1000);
    tick();
</script>

<?php include 'includes/footer.php'; ?>