<?php
require_once '../config.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['success' => false, 'message' => 'Method not allowed']);
    exit;
}

// Security Check
$headers = getallheaders();
$csrf_token = $headers['X-CSRF-TOKEN'] ?? '';
if (!validateCSRF($csrf_token)) {
    echo json_encode(['success' => false, 'message' => 'Security Token Mismatch']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);
$employee_code = trim($data['employee_code'] ?? '');

if (empty($employee_code)) {
    echo json_encode(['success' => false, 'message' => 'ข้อมูล QR ไม่ถูกต้อง']);
    exit;
}

// Find User
$stmt = $pdo->prepare("SELECT id, name FROM users WHERE employee_code = ?");
$stmt->execute([$employee_code]);
$user = $stmt->fetch();

if (!$user) {
    echo json_encode(['success' => false, 'message' => 'ไม่พบข้อมูลพนักงานในระบบ']);
    exit;
}

$today = date('Y-m-d');
$time_now = date('H:i:s');

// Check existing
$stmt = $pdo->prepare("SELECT * FROM attendance WHERE user_id = ? AND work_date = ?");
$stmt->execute([$user['id'], $today]);
$att = $stmt->fetch();

if (!$att) {
    // Check-in
    $status = (strtotime($time_now) > strtotime('09:00:00')) ? 'late' : 'normal';
    $stmt = $pdo->prepare("INSERT INTO attendance (user_id, work_date, check_in, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$user['id'], $today, $time_now, $status]);
    echo json_encode(['success' => true, 'message' => "เช็คอิน: " . $user['name'] . " เวลา " . $time_now]);
} else {
    // Check-out logic
    if ($att['check_out'] === null) {
        $stmt = $pdo->prepare("UPDATE attendance SET check_out = ? WHERE id = ?");
        $stmt->execute([$time_now, $att['id']]);
        echo json_encode(['success' => true, 'message' => "เช็คเอาท์: " . $user['name'] . " เวลา " . $time_now]);
    } else {
        echo json_encode(['success' => false, 'message' => "พนักงานท่านนี้ลงเวลาครบแล้ววันนี้"]);
    }
}
?>