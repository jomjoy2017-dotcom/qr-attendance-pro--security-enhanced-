<?php
require_once 'config.php';
checkLogin();
hasRole(['admin', 'hr']);

$date = $_GET['date'] ?? '';
$month = $_GET['month'] ?? '';
$params = [];
$sql = "SELECT a.*, u.name, u.employee_code FROM attendance a JOIN users u ON a.user_id = u.id WHERE 1=1";
if ($date) { $sql .= " AND a.work_date = ?"; $params[] = $date; }
if ($month) { $sql .= " AND MONTH(a.work_date) = ?"; $params[] = $month; }
$sql .= " ORDER BY a.work_date DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$filename = "Report_" . date('Ymd_His') . ".txt";
header('Content-Type: text/plain');
header('Content-Disposition: attachment; filename="' . $filename . '"');

echo str_pad("CODE", 15) . str_pad("NAME", 25) . str_pad("DATE", 15) . str_pad("IN", 10) . str_pad("OUT", 10) . "STATUS" . PHP_EOL;
echo str_repeat("=", 80) . PHP_EOL;

foreach($rows as $r) {
    echo str_pad($r['employee_code'], 15) . 
         str_pad($r['name'], 25) . 
         str_pad($r['work_date'], 15) . 
         str_pad($r['check_in'] ?? '--:--', 10) . 
         str_pad($r['check_out'] ?? '--:--', 10) . 
         $r['status'] . PHP_EOL;
}
exit;