<?php
require_once 'config.php';
checkLogin();
include 'includes/header.php';

$date = $_GET['date'] ?? '';
$month = $_GET['month'] ?? '';
$params = [];
$sql = "SELECT a.*, u.name, u.employee_code 
        FROM attendance a 
        JOIN users u ON a.user_id = u.id 
        WHERE 1=1";

if ($_SESSION['role'] === 'employee') {
    $sql .= " AND a.user_id = ?";
    $params[] = $_SESSION['user_id'];
}

if ($date) {
    $sql .= " AND a.work_date = ?";
    $params[] = $date;
}

if ($month) {
    $sql .= " AND MONTH(a.work_date) = ?";
    $params[] = $month;
}

$sql .= " ORDER BY a.work_date DESC, a.check_in DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();
?>

<div class="bg-white rounded-2xl shadow-sm p-8">
    <div class="flex flex-col md:flex-row justify-between items-center mb-8 gap-4">
        <h2 class="text-2xl font-bold">ประวัติการลงเวลา</h2>
        <?php if($_SESSION['role'] !== 'employee'): ?>
            <a href="export.php?date=<?php echo urlencode($date); ?>&month=<?php echo urlencode($month); ?>" class="bg-slate-800 text-white px-5 py-2 rounded-lg font-bold">Export TXT</a>
        <?php endif; ?>
    </div>

    <form class="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8 bg-gray-50 p-4 rounded-xl">
        <input type="date" name="date" value="<?php echo htmlspecialchars($date); ?>" class="p-2 border rounded-lg">
        <select name="month" class="p-2 border rounded-lg">
            <option value="">ทุกเดือน</option>
            <?php for($i=1; $i<=12; $i++): ?>
                <option value="<?php echo $i; ?>" <?php echo ($month == $i) ? 'selected' : ''; ?>><?php echo date('F', mktime(0,0,0,$i,1)); ?></option>
            <?php endfor; ?>
        </select>
        <button type="submit" class="bg-indigo-600 text-white rounded-lg px-4 py-2">กรองข้อมูล</button>
        <a href="history.php" class="bg-gray-300 text-center rounded-lg px-4 py-2">ล้าง</a>
    </form>

    <div class="overflow-x-auto">
        <table class="w-full text-left border-collapse">
            <thead>
                <tr class="bg-gray-100 text-gray-600 text-sm uppercase">
                    <th class="p-4">วันที่</th>
                    <th class="p-4">พนักงาน</th>
                    <th class="p-4 text-center">เช็คอิน</th>
                    <th class="p-4 text-center">เช็คเอาท์</th>
                    <th class="p-4 text-center">สถานะ</th>
                </tr>
            </thead>
            <tbody class="divide-y">
                <?php foreach($rows as $r): ?>
                <tr class="hover:bg-indigo-50 transition">
                    <td class="p-4 font-mono"><?php echo htmlspecialchars($r['work_date']); ?></td>
                    <td class="p-4">
                        <div class="font-bold"><?php echo htmlspecialchars($r['name']); ?></div>
                        <div class="text-xs text-gray-400"><?php echo htmlspecialchars($r['employee_code']); ?></div>
                    </td>
                    <td class="p-4 text-center font-mono text-emerald-600 font-bold"><?php echo htmlspecialchars($r['check_in'] ?? '--:--'); ?></td>
                    <td class="p-4 text-center font-mono text-indigo-600 font-bold"><?php echo htmlspecialchars($r['check_out'] ?? '--:--'); ?></td>
                    <td class="p-4 text-center">
                        <span class="px-3 py-1 rounded-full text-xs font-bold <?php echo ($r['status'] == 'late') ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'; ?>">
                            <?php echo ($r['status'] == 'late') ? 'มาสาย' : 'ปกติ'; ?>
                        </span>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include 'includes/footer.php'; ?>