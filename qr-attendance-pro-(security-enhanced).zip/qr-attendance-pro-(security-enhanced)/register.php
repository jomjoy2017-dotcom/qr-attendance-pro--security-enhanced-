<?php
require_once 'config.php';

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validateCSRF($_POST['csrf_token'] ?? '')) {
        $error = 'Security Token mismatch';
    } else {
        $name = strip_tags($_POST['name']);
        $email = filter_var($_POST['email'], FILTER_VALIDATE_EMAIL);
        $password = password_hash($_POST['password'], PASSWORD_BCRYPT);
        $role = in_array($_POST['role'], ['admin', 'hr', 'employee']) ? $_POST['role'] : 'employee';
        $employee_code = 'EMP' . mt_rand(100000, 999999);

        if (!$email) {
            $error = "รูปแบบอีเมลไม่ถูกต้อง";
        } else {
            try {
                $stmt = $pdo->prepare("INSERT INTO users (employee_code, name, email, password, role) VALUES (?, ?, ?, ?, ?)");
                $stmt->execute([$employee_code, $name, $email, $password, $role]);
                $success = "สมัครสำเร็จ! รหัสพนักงานของคุณคือ: $employee_code";
            } catch (PDOException $e) {
                $error = "อีเมลหรือข้อมูลซ้ำในระบบ";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <title>Register - QR Attendance</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Prompt&display=swap" rel="stylesheet">
</head>
<body class="bg-slate-100 min-h-screen flex items-center justify-center" style="font-family: 'Prompt', sans-serif;">
    <div class="bg-white p-10 rounded-2xl shadow-xl w-full max-w-lg">
        <h2 class="text-2xl font-bold text-center mb-8">ลงทะเบียนพนักงาน</h2>
        <?php if($success): ?>
            <div class="bg-green-100 text-green-700 p-4 rounded mb-6 text-center font-bold"><?php echo htmlspecialchars($success); ?></div>
            <a href="login.php" class="block bg-indigo-600 text-white text-center py-3 rounded-lg">ไปหน้าล็อกอิน</a>
        <?php else: ?>
            <?php if($error): ?><div class="bg-red-100 text-red-700 p-4 rounded mb-6"><?php echo htmlspecialchars($error); ?></div><?php endif; ?>
            <form method="POST" class="space-y-4">
                <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
                <div>
                    <label class="block text-sm font-medium text-gray-700">ชื่อ-นามสกุล</label>
                    <input type="text" name="name" required class="w-full p-3 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">อีเมล</label>
                    <input type="email" name="email" required class="w-full p-3 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">รหัสผ่าน</label>
                    <input type="password" name="password" required class="w-full p-3 border rounded-lg">
                </div>
                <div>
                    <label class="block text-sm font-medium text-gray-700">ระดับผู้ใช้งาน</label>
                    <select name="role" class="w-full p-3 border rounded-lg">
                        <option value="employee">พนักงาน (Employee)</option>
                        <option value="hr">ฝ่ายบุคคล (HR)</option>
                        <option value="admin">ผู้ดูแลระบบ (Admin)</option>
                    </select>
                </div>
                <button type="submit" class="w-full bg-emerald-600 text-white font-bold py-3 rounded-lg hover:bg-emerald-700">บันทึกข้อมูล</button>
                <a href="login.php" class="block text-center text-gray-500 text-sm">กลับหน้าล็อกอิน</a>
            </form>
        <?php endif; ?>
    </div>
</body>
</html>