<?php
require_once 'config.php';
checkLogin();
hasRole(['admin', 'hr']);
include 'includes/header.php';
?>

<div class="max-w-xl mx-auto">
    <div class="bg-white rounded-3xl shadow-2xl overflow-hidden">
        <div class="bg-indigo-600 p-6 text-white text-center">
            <h2 class="text-2xl font-bold">สแกนรหัสพนักงาน</h2>
            <p class="text-indigo-100">Scan QR Code to Check-in/out</p>
        </div>
        <div class="p-6">
            <div id="reader" class="w-full rounded-2xl overflow-hidden border-4 border-gray-100"></div>
            <div id="scan-feedback" class="mt-6 transition-all duration-300"></div>
        </div>
    </div>
</div>

<script src="https://unpkg.com/html5-qrcode"></script>
<script>
    const feedback = document.getElementById('scan-feedback');

    function onScanSuccess(decodedText) {
        // Visual feedback
        feedback.innerHTML = `<div class="bg-indigo-100 text-indigo-700 p-4 rounded-xl text-center font-bold animate-pulse">กำลังตรวจสอบ: ${decodedText}...</div>`;
        
        // Call API
        fetch('api/record_attendance.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'X-CSRF-TOKEN': '<?php echo $_SESSION['csrf_token']; ?>'
            },
            body: JSON.stringify({ employee_code: decodedText })
        })
        .then(res => res.json())
        .then(data => {
            if(data.success) {
                feedback.innerHTML = `<div class="bg-emerald-100 text-emerald-700 p-4 rounded-xl text-center border-2 border-emerald-500">
                    <p class="text-lg">✅ สำเร็จ!</p>
                    <p>${data.message}</p>
                </div>`;
            } else {
                feedback.innerHTML = `<div class="bg-rose-100 text-rose-700 p-4 rounded-xl text-center border-2 border-rose-500">
                    <p class="text-lg">❌ ข้อผิดพลาด</p>
                    <p>${data.message}</p>
                </div>`;
            }
            
            // Auto clear feedback after 4 seconds
            setTimeout(() => { feedback.innerHTML = ''; }, 4000);
        })
        .catch(err => {
            feedback.innerHTML = `<div class="bg-red-600 text-white p-4 rounded-xl text-center">Network Error</div>`;
        });
    }

    const html5QrcodeScanner = new Html5QrcodeScanner("reader", { fps: 10, qrbox: 250 });
    html5QrcodeScanner.render(onScanSuccess);
</script>

<?php include 'includes/footer.php'; ?>